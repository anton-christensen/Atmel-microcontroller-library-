// Standard libs
#include <avr/io.h>

// Aatg libs
#include "aatg/lcd.h"

// Programs
#include "programs/splashDLL.c"
#include "programs/breakout.c"

int main() {
	Splash();

	Breakout();
	
	lcd_clear();
	lcd_gotoxy(4,1);
	lcd_puts("Hello World!");
	return 0;
}