 /** 
  * File:    lcd.h 
  * 
  * Author1:  Anton Christensen (anton.christensen9700@gmail.com)
  * Date:     Winter 2014 
  * 
  * Description: 
  * 	Custom built library functionality for using the school
  *		dev board with a 20x4 character display.
  *
  */

#ifndef __lcd_h__
#define __lcd_h__

#define LCDPORT PORTC
#define LCDPIN PINC
#define LCDDDR DDRC
#define RS 0
#define RW 1
#define EN 2
#define BL 3 // backlight switch
#define BF 7
#define D4 4
#define D5 5
#define D6 6
#define D7 7

#define true 1
#define false 0

typedef unsigned char byte;
typedef unsigned char bool;

#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>

#include "extraChars.h"

bool lcd_initialised = false;
int cursor_pos_x = 0;
int cursor_pos_y = 0;

void _lcd_flash();
void _lcd_check_busy();
void _lcd_write_nibble(unsigned char cmd, bool rs);
void _lcd_write_byte(unsigned char byte, unsigned char rs);
void _lcd_set_cgram_address(unsigned char addr);
void _lcd_set_ddram_address(unsigned char addr);
void lcd_write_instruction(unsigned char instruction);
void lcd_write_data(unsigned char data);
bool lcd_gotoxy(unsigned char x, unsigned char y);
void lcd_clear();
void lcd_puts(char* str);
void lcd_puti(int i);
void lcd_set_char(unsigned char addr, unsigned char* rows);
void lcd_init();

void _lcd_flash() {
	_delay_us(10);
	LCDPORT |=  (1<<EN);
	_delay_us(10);
	LCDPORT &= ~(1<<EN);
	_delay_us(100);
}

void _lcd_check_busy() {
	LCDDDR = 1<<EN | 1<<RW | 1<<RS;
	LCDPORT |=  (1<<RW);
	LCDPORT &= ~(1<<RS);

	while (LCDPIN & (1<<BF)) {
		_lcd_flash();
	}

	LCDDDR = 0xFF;
	LCDPORT &= ~(1<<RW);
}

void _lcd_write_nibble(unsigned char nibble, bool rs) {
	//_lcd_check_busy();
	LCDPORT &= ~(0x0F<<D4);
	LCDPORT &= ~(1<<RW); 		// Write mode
	if(rs)
		LCDPORT |=  (1<<RS); 	// Data mode
	else
		LCDPORT &= ~(1<<RS);	// Command mode
	
	LCDPORT |=  (nibble<<D4);
	_lcd_flash();
}

void _lcd_write_byte(unsigned char byte, unsigned char rs) {
	_lcd_write_nibble((byte >> 4) & 0x0F, rs); 	// Send latter four bits
	_lcd_write_nibble(byte & 0x0F, rs);  		// Send former fout bits
}

void _lcd_set_cgram_address(unsigned char addr) {
	addr %= 0b01000000;
	_lcd_write_byte((0b01000000 | (addr)),0); // Set character address
}

void _lcd_set_ddram_address(unsigned char addr) {
	//addr %= 0b10000000;
	_lcd_write_byte((0b10000000 | addr),0); // Set character address
}

void lcd_write_instruction(unsigned char instruction) {
	_lcd_write_byte(instruction, 0);
}

void lcd_write_data(unsigned char data) {
	_lcd_write_byte(data, 1);
}

bool lcd_gotoxy(unsigned char x, unsigned char y) {
	if(x >= 20 || y >= 4)
		return false;
	
	int addr = x;
	switch(y) {
		case 1:
			addr += 0x40;
			break;
		case 2:
			addr += 0x14;
			break;
		case 3:
			addr += 0x54;
			break;
	}
	cursor_pos_x = x;
	cursor_pos_y = y;
	_lcd_set_ddram_address(addr);
	return true;
}

void lcd_clear() {
	_lcd_write_byte(1,0);
	_delay_ms(2);
	cursor_pos_x = 0;
	cursor_pos_y = 0;
}

void _lcd_put_danish(char c) {
	
	switch(c) {
		case 'ø':
			lcd_set_char(7, oe);
			_lcd_write_byte(7,1);
			break;
		default:
			_lcd_write_byte(c,1);
	}
	
	_lcd_write_byte(c,1);
}

void lcd_puts(char* str) {
	int i = 0;
	while(str[i] != '\0') {
		if(cursor_pos_y > 3 && cursor_pos_x >= 20)
			return;
		
		if(str[i] == '\n') {
			if(lcd_gotoxy(0, cursor_pos_y+1)) {
				i++;
				continue;
			}
			else
				return;
		} 
		else if(cursor_pos_x == 20) {
			if(!lcd_gotoxy(0,cursor_pos_y+1))
				return;
		}
		
		//_lcd_put_danish(str[i]);
		_lcd_write_byte(str[i],1);
		cursor_pos_x++;
		i++;
	}
}

void lcd_puti(int i) {
	char buffer[20];
	itoa(i, buffer, 10);
	lcd_puts(buffer);
}

void lcd_set_char(unsigned char addr, unsigned char* rows) {
	addr %= 8;
	addr *= 8;

	_lcd_set_cgram_address(addr);
	char i;
	for(i = 0; i < 8; i++) {
		_lcd_write_byte((*(rows+i)) & 0x1F, 1);
	}
	
	lcd_gotoxy(0,0); // reset position so that we are no longer writing to CGRAM but instead 
}

void lcd_init() {
	if(lcd_initialised)
		return;
	lcd_initialised = true;
	LCDDDR = 0xFF;

	_delay_ms(50);	//Wait for boot
	//Function set
	_lcd_write_nibble(0b0010,0);	// Set 4-bit mode
	_delay_ms(1);
	_lcd_write_byte(0b00101000,0);	// Set 2-line mode and display off
	_delay_us(50);
	_lcd_write_byte(0b00001100,0);	// display on, cursor off, blink off
	_delay_us(50);
	_lcd_write_byte(0b00000001,0);	//clear display
	_delay_ms(2);
	_lcd_write_byte(0b00000110,0);	// set increment mode and entire shifts off
	_delay_ms(2);

	LCDPORT = 1<<BL; // turn on backlight
}

#endif