#ifndef __EXTRA_CHARS__
#define __EXTRA_CHARS__

unsigned char oe[] = {
 					0b00000,
					0b00000,
					0b01111,
					0b10011, ///   #
					0b10101, ///  ###
					0b11001, ///   #
					0b11110,
					0b00000};

#endif