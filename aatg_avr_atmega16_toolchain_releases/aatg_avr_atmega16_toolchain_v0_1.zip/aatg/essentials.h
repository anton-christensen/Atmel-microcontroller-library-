#ifndef __AATG_ESSENTIALS__
#define __AATG_ESSENTIALS__

#include <avr/io.h>

#define OC0 3 //PB3 // 8bit clock pin
#define PWM0 OCR0

// volatile uint8_t *port

// normalize
int norm(int x) { return x < 0 ? -x : x; }

// variable delay function
void delay_ms(unsigned long long n) {
	while(n--)
		_delay_ms(1);
}

unsigned int duty_cycle(int percentage) {
	return (0xFF*percentage)/100;
}

void pwm0_init() {
	DDRB |= 1<<OC0; //Make PortB.3 as output to generate PWM on OC0 (PB3)
	TCCR0 |= 1<<WGM00 /*| 1<<WGM01*/ | 1<<COM01 | 1<<CS01; //Configure fast PWM, non-inverted, without prescaler
}

void pwm0_set(int speed) {
	PWM0 = duty_cycle(norm(speed));
}

#endif